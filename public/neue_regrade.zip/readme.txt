Neue Regrade is a free to use sophisticated variable sans serif typeface, which combines the smooth curves of gothic typography and the slight inktraps in modern typefaces. It started as a university project, but due to my obsession to the beauty of typography I made them 6 weights with matching slant, some ligatures and some styles including the letter a, g, o, f, t and k. 

Hope you are going to like it and feel free to use it for your personal and commercial projects :).

Made at: Media & Design institue EKCU Egere, Hungary @media_design_eger 
Made by: Ungvári József @joci.ungvari 
Consultant: Zeman Zoltán

Appreciate and follow:
https://www.behance.net/ujmotion

Pay what you like:
https://jociungvari.gumroad.com/l/neueregrade